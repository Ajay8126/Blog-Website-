 import { useState } from "react";

export default function BlogForm({ setPosts, setPage }) {
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [content, setContent] = useState("");

  const submit = (e) => {
    e.preventDefault();
    setPosts(p => [...p, { id: Date.now(), title, author, content }]);
    setPage("list");
  };

  return (
    <form className="form" onSubmit={submit}>
      <h2>Create Blog</h2>
      <input placeholder="Title" required onChange={e => setTitle(e.target.value)} />
      <input placeholder="Author" required onChange={e => setAuthor(e.target.value)} />
      <textarea placeholder="Content" required onChange={e => setContent(e.target.value)} />
      <button>Publish</button>
    </form>
  );
}
