 export default function BlogList({ posts, openPost }) {
  return (
    <div className="container">
      {posts.map(p => (
        <div className="card" key={p.id}>
          <h3>{p.title}</h3>
          <p><b>{p.author}</b></p>
          <p>{p.content.slice(0, 100)}...</p>
          <button onClick={() => openPost(p)}>Read More</button>
        </div>
      ))}
    </div>
  );
}
