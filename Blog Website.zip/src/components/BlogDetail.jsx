 export default function BlogDetail({ post, setPage }) {
  if (!post) return null;

  return (
    <div className="detail">
      <h2>{post.title}</h2>
      <p><b>{post.author}</b></p>
      <p>{post.content}</p>
      <button onClick={() => setPage("list")}>Back</button>
    </div>
  );
}
