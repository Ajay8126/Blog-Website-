 export default function Navbar({ setPage }) {
  return (
    <nav className="navbar">
      <h2>📝 Blog Website</h2>
      <div>
        <button onClick={() => setPage("list")}>Home</button>
        <button onClick={() => setPage("create")}>Create Blog</button>
      </div>
    </nav>
  );
}
