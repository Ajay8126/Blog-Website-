 import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import BlogList from "./components/BlogList";
import BlogForm from "./components/BlogForm";
import BlogDetail from "./components/BlogDetail";
import "./App.css";

export default function App() {
  const [posts, setPosts] = useState(
    JSON.parse(localStorage.getItem("posts")) || []
  );
  const [page, setPage] = useState("list");
  const [selectedPost, setSelectedPost] = useState(null);

  useEffect(() => {
    localStorage.setItem("posts", JSON.stringify(posts));
  }, [posts]);

  return (
    <>
      <Navbar setPage={setPage} />
      {page === "list" && (
        <BlogList posts={posts} openPost={(p) => {
          setSelectedPost(p);
          setPage("detail");
        }} />
      )}
      {page === "create" && <BlogForm setPosts={setPosts} setPage={setPage} />}
      {page === "detail" && (
        <BlogDetail post={selectedPost} setPage={setPage} />
      )}
    </>
  );
}
